# CloudTrail CIS Demo

## Deploy

terraform init
terraform plan
terraform apply

Confirm the SNS email subscription.

## Test

aws s3 mb s3://<temporary-bucket>
aws s3 rb s3://<temporary-bucket>

Verify:
1. CloudTrail Event History
2. CloudWatch Logs
3. Metric Filter
4. Alarm state
5. SNS email
